import React from "react";

function VideoCall() {
  return <div>VideoCall</div>;
}

export default VideoCall;

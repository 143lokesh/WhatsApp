import React from "react";

function VoiceCall() {
  return <div>VoiceCall</div>;
}

export default VoiceCall;

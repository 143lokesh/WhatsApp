import React from "react";

function Chat() {
  return <div>Chat</div>;
}

export default Chat;

import React from "react";

function ChatContainer() {
  return <div>ChatContainer</div>;
}

export default ChatContainer;

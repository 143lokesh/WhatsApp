import React from "react";

function ChatGroupContainer() {
  return <div>ChatGroupContainer</div>;
}

export default ChatGroupContainer;

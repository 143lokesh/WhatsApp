import React from "react";

function ChatHeader() {
  return <div>ChatHeader</div>;
}

export default ChatHeader;

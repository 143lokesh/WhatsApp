import React from "react";

function ImageMessage() {
  return <div>ImageMessage</div>;
}

export default ImageMessage;

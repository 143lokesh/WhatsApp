import React from "react";

function MessageBar() {
  return <div>MessageBar</div>;
}

export default MessageBar;

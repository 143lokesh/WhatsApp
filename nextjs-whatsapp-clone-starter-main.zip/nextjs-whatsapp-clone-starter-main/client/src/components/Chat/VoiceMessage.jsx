import React from "react";

function VoiceMessage() {
  return <div>VoiceMessage</div>;
}

export default VoiceMessage;

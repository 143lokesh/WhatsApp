import React from "react";

function ChatLIstItem() {
  return <div>ChatLIstItem</div>;
}

export default ChatLIstItem;

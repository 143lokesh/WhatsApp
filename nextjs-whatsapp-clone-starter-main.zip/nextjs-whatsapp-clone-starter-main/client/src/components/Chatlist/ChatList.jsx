import React from "react";

function ChatList() {
  return <div>ChatList</div>;
}

export default ChatList;

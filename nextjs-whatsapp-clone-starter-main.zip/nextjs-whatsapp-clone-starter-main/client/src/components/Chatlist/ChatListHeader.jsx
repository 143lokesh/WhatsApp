import React from "react";

function ChatListHeader() {
  return <div>ChatListHeader</div>;
}

export default ChatListHeader;

import React from "react";

function ContactsList() {
  return <div>ContactsList</div>;
}

export default ContactsList;

import React from "react";

function Empty() {
  return <div>Empty</div>;
}

export default Empty;

import React from "react";

function Avatar() {
  return <div>Avatar</div>;
}

export default Avatar;

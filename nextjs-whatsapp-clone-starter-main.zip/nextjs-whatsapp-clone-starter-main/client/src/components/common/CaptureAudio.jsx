import React from "react";

function CaptureAudio() {
  return <div>CaptureAudio</div>;
}

export default CaptureAudio;

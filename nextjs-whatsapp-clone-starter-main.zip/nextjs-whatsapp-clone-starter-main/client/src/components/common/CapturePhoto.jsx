import React from "react";

function CapturePhoto() {
  return <div>CapturePhoto</div>;
}

export default CapturePhoto;

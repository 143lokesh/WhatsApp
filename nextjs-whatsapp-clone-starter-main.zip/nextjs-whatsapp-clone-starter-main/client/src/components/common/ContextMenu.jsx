import React from "react";

function ContextMenu() {
  return <div>ContextMenu</div>;
}

export default ContextMenu;

import React from "react";

function IncomingCall() {
  return <div>IncomingCall</div>;
}

export default IncomingCall;

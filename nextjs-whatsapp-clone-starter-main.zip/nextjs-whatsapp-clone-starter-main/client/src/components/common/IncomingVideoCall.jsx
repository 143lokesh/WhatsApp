import React from "react";

function IncomingVideoCall() {
  return <div>IncomingVideoCall</div>;
}

export default IncomingVideoCall;

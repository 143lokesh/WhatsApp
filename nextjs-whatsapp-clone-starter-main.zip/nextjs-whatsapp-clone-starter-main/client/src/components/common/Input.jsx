import React from "react";

function Input() {
  return <div>Input</div>;
}

export default Input;

import React from "react";

function MessageStatus() {
  return <div>MessageStatus</div>;
}

export default MessageStatus;

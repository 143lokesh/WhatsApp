import React from "react";

function PhotoLibrary() {
  return <div>PhotoLibrary</div>;
}

export default PhotoLibrary;

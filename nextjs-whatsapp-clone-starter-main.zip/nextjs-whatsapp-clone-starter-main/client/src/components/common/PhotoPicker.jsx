import React from "react";

function PhotoPicker() {
  return <div>PhotoPicker</div>;
}

export default PhotoPicker;

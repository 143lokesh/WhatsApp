import React from "react";

function logout() {
  return <div>logout</div>;
}

export default logout;

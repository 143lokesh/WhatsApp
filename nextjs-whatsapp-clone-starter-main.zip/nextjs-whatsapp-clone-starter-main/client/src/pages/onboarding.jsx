import React from "react";

function onboarding() {
  return <div>onboarding</div>;
}

export default onboarding;
